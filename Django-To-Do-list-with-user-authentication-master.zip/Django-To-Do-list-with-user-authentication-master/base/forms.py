from django import forms
from .models import Task

class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ['title', 'description', 'complete']
        labels = {
            'title': 'Назва',
            'description': 'Опис',
            'complete': 'Виконано',
        }


class PositionForm(forms.Form):
    position = forms.CharField()

from django.contrib.auth.forms import AuthenticationForm

class CustomLoginForm(AuthenticationForm):
    username = forms.CharField(label="Ім'я користувача")
    password = forms.CharField(label="Пароль", widget=forms.PasswordInput)

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class CustomUserCreationForm(UserCreationForm):
    class Meta:
        model = User
        fields = ('username', 'password1', 'password2')
        labels = {
            'username': "Ім'я користувача",
            'password1': 'Пароль',
            'password2': 'Підтвердження пароля',
        }
